import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.text2sql.agent.execution.QueryResult;
import com.text2sql.agent.execution.ResultNormalizer;
import java.nio.file.*;
import java.util.*;

/** External common V4 scorer. No generator, Spring context, SQL execution or model client. */
public final class ReferenceContractScorer {
    private static final ObjectMapper JSON = new ObjectMapper();
    public record Policy(String mode, List<Integer> keyPositions, Integer requestedLimit) { }

    public static boolean equivalent(QueryResult gold, QueryResult actual, Policy policy) {
        if (gold == null || actual == null || policy == null || policy.mode() == null)
            throw new IllegalArgumentException("Missing reference, result, or explicit policy");
        if (!Set.of("UNORDERED_MULTISET_OR_SINGLE_ROW", "TOTAL_ORDER_STRICT_TOP_N", "TIME_ASC", "PARTIAL_ORDER").contains(policy.mode()))
            throw new IllegalArgumentException("Unknown score policy");
        if (gold.truncated() || actual.truncated() || gold.columns().size() != actual.columns().size()) return false;
        int width = gold.columns().size();
        if (gold.rows().stream().anyMatch(r -> r.size() != width) || actual.rows().stream().anyMatch(r -> r.size() != width))
            return false;
        if (policy.requestedLimit() != null && (policy.requestedLimit() < 1
                || gold.rows().size() > policy.requestedLimit() || actual.rows().size() > policy.requestedLimit()))
            throw new IllegalArgumentException("Results violate registered TopN contract");
        // Full multiset equality is mandatory: an equal score never authorizes a forged identity.
        if (!ResultNormalizer.normalize(gold, false).equals(ResultNormalizer.normalize(actual, false))) return false;
        if (policy.mode().equals("UNORDERED_MULTISET_OR_SINGLE_ROW")) return true;
        var expected = ResultNormalizer.normalize(gold, true);
        var observed = ResultNormalizer.normalize(actual, true);
        if (policy.mode().equals("TOTAL_ORDER_STRICT_TOP_N")) return expected.equals(observed);
        if (policy.keyPositions() == null || policy.keyPositions().isEmpty()
                || policy.keyPositions().stream().anyMatch(i -> i == null || i < 0 || i >= width))
            throw new IllegalArgumentException("Missing/invalid registered ordering column");
        // Full values already match. Only permutations inside equal requested key blocks are allowed.
        for (int r = 0; r < expected.size(); r++)
            for (int key : policy.keyPositions())
                if (!expected.get(r).get(key).equals(observed.get(r).get(key))) return false;
        return true;
    }

    private static QueryResult result(List<List<String>> rows) {
        int width = rows.isEmpty() ? 2 : rows.getFirst().size();
        var columns = new ArrayList<String>();
        for (int i = 0; i < width; i++) columns.add("c" + i);
        return new QueryResult(columns, rows, false, 0);
    }
    private static List<String> row(String... values) { return Arrays.asList(values); }
    private static List<List<String>> rows(String... values) { return List.of(row(values)); }
    private static void check(List<Map<String,Object>> checks, String id, boolean condition) {
        checks.add(Map.of("id", id, "passed", condition));
        if (!condition) throw new IllegalStateException("Scoring counterexample failed: " + id);
    }

    private static void selfcheck(Path output) throws Exception {
        var checks = new ArrayList<Map<String,Object>>();
        var unordered = new Policy("UNORDERED_MULTISET_OR_SINGLE_ROW", List.of(), null);
        var partial = new Policy("PARTIAL_ORDER", List.of(1), null);
        var time = new Policy("TIME_ASC", List.of(0), null);
        var top = new Policy("TOTAL_ORDER_STRICT_TOP_N", List.of(), 2);
        var sorted = result(List.of(row("A","10"),row("B","5")));
        var reversed = result(List.of(row("B","5"),row("A","10")));
        check(checks,"unordered_accepts_permutation",equivalent(sorted,reversed,unordered));
        check(checks,"ordered_without_limit_rejects_reverse",!equivalent(sorted,reversed,partial));
        check(checks,"ordered_without_limit_accepts_exact",equivalent(sorted,sorted,partial));
        var ties = result(List.of(row("A","10"),row("B","10"),row("C","5")));
        check(checks,"equal_key_block_permutation",equivalent(ties,result(List.of(row("B","10"),row("A","10"),row("C","5"))),partial));
        check(checks,"moving_row_across_tie_block",!equivalent(ties,result(List.of(row("B","10"),row("C","5"),row("A","10"))),partial));
        check(checks,"strict_topn_stable_id",!equivalent(sorted,reversed,top));
        check(checks,"strict_topn_forged_tail_id",!equivalent(sorted,result(List.of(row("A","10"),row("FORGED","5"))),top));
        check(checks,"strict_topn_hidden_key_uses_gold_order",!equivalent(sorted,reversed,top));
        check(checks,"no_row_dedup",!equivalent(result(List.of(row("A","1"),row("A","1"))),result(rows("A","1")),unordered));
        check(checks,"no_pivot_repair",!equivalent(sorted,result(rows("10","5")),unordered));
        check(checks,"no_extra_column",!equivalent(sorted,result(List.of(row("A","10","X"),row("B","5","Y"))),unordered));
        check(checks,"no_unit_scaling",!equivalent(result(rows("rate","3.12")),result(rows("rate","0.0312")),unordered));
        check(checks,"original_numeric_tolerance",equivalent(result(rows("amount","10.00000")),result(rows("amount","10")),unordered));
        check(checks,"year_is_not_january_date",!equivalent(result(rows("2018","1")),result(rows("2018-01-01","1")),time));
        var dates = result(List.of(row("2018-01-01","1"),row("2018-02-01","2")));
        check(checks,"chronology_rejects_reverse",!equivalent(dates,result(List.of(row("2018-02-01","2"),row("2018-01-01","1"))),time));
        check(checks,"midnight_date_equivalence",equivalent(result(rows("2018-01-01","1")),result(rows("2018-01-01 00:00:00","1")),time));
        check(checks,"null_is_not_zero",!equivalent(result(rows("A",null)),result(rows("A","0")),unordered));
        check(checks,"null_is_not_empty",!equivalent(result(rows("A",null)),result(rows("A","")),unordered));
        check(checks,"truncation_rejected",!equivalent(sorted,new QueryResult(sorted.columns(),sorted.rows(),true,0),unordered));
        var many = new ArrayList<List<String>>();
        for (int i=0;i<101;i++) many.add(row("id"+i,"1"));
        check(checks,"all_101_groups_required",!equivalent(result(many),result(many.subList(0,100)),unordered));
        check(checks,"zero_rows_still_checks_width",!equivalent(new QueryResult(List.of("A"),List.of(),false,0),new QueryResult(List.of("A","B"),List.of(),false,0),unordered));
        boolean rejected=false;
        try { equivalent(sorted,sorted,new Policy("PARTIAL_ORDER",List.of(20),null)); } catch(IllegalArgumentException e) { rejected=true; }
        check(checks,"invalid_keys_fail_closed",rejected);
        rejected=false;
        try { equivalent(sorted,sorted,new Policy("LEGACY_GUESS_FROM_SQL",List.of(),null)); } catch(IllegalArgumentException e) { rejected=true; }
        check(checks,"unknown_policy_fail_closed",rejected);
        try (var out = Files.newOutputStream(output, StandardOpenOption.CREATE_NEW)) {
            JSON.writerWithDefaultPrettyPrinter().writeValue(out,Map.of("format","public-reference-scorer-counterexamples-v1",
                "checks",checks,"passed",checks.size(),"providerCalls",0,"providerCostYuan",0,
                "runtimeIntegration","NOT_ADMITTED_UNTIL_D_COMMON_CONTROLLER"));
        }
        System.out.println("SCORER_BOUNDARIES passed="+checks.size()+" providerCalls=0");
    }

    public static void main(String[] args) throws Exception {
        if(args.length!=2) throw new IllegalArgumentException("selfcheck output.json OR score fixture.json");
        if(args[0].equals("selfcheck")) selfcheck(Path.of(args[1]));
        else if(args[0].equals("score")) {
            JsonNode input=JSON.readTree(Path.of(args[1]).toFile());
            var gold=JSON.treeToValue(input.get("gold"),QueryResult.class);
            var actual=JSON.treeToValue(input.get("actual"),QueryResult.class);
            var policy=JSON.treeToValue(input.get("policy"),Policy.class);
            System.out.println(JSON.writeValueAsString(Map.of("correct",equivalent(gold,actual,policy))));
        } else throw new IllegalArgumentException("Unknown operation");
    }
}
