package com.text2sql.agent.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.ArrayList;
import java.util.List;

/**
 * 全项目的外部可调参数集中在这里，对应 application.yml 的 agent.* 前缀。
 *
 * <p>为什么不用 @Value 散落各处：阶段 1 的验收标准之一是「每个阶段必须产出数字」，
 * 而数字只有在参数集中、可复现时才有意义。阶段 6 做消融实验时会反复改这些值，
 * 集中在一个类里才能一眼看出「这次实验到底改了哪几个旋钮」。
 */
@ConfigurationProperties(prefix = "agent")
public class AgentProperties {

    private Db db = new Db();
    private Guard guard = new Guard();
    private Llm llm = new Llm();
    private Prompt prompt = new Prompt();
    private Retrieval retrieval = new Retrieval();
    private Semantic semantic = new Semantic();
    private Clarification clarification = new Clarification();
    private SelfCorrection selfCorrection = new SelfCorrection();
    private Cache cache = new Cache();
    private Observability observability = new Observability();
    private Routing routing = new Routing();
    private Persistence persistence = new Persistence();
    private Fewshot fewshot = new Fewshot();
    private ResultCheckerConfig resultChecker = new ResultCheckerConfig();
    private ToolUse toolUse = new ToolUse();
    private Conversation conversation = new Conversation();
    private Eval eval = new Eval();
    private RequestBudgetConfig requestBudget = new RequestBudgetConfig();

    public RequestBudgetConfig getRequestBudget() { return requestBudget; }
    public void setRequestBudget(RequestBudgetConfig requestBudget) { this.requestBudget = requestBudget; }

    public static class RequestBudgetConfig {
        // Enabled explicitly in application.yml; bare unit fixtures retain their synchronous contract.
        private boolean enabled;
        private long timeoutMs = 15000;
        private int maxModelCalls = 2;
        private long minRetryRemainingMs = 2000;
        public boolean isEnabled() { return enabled; }
        public void setEnabled(boolean enabled) { this.enabled = enabled; }
        public long getTimeoutMs() { return timeoutMs; }
        public void setTimeoutMs(long timeoutMs) { this.timeoutMs = timeoutMs; }
        public int getMaxModelCalls() { return maxModelCalls; }
        public void setMaxModelCalls(int maxModelCalls) { this.maxModelCalls = maxModelCalls; }
        public long getMinRetryRemainingMs() { return minRetryRemainingMs; }
        public void setMinRetryRemainingMs(long minRetryRemainingMs) { this.minRetryRemainingMs = minRetryRemainingMs; }
    }

    public ToolUse getToolUse() {
        return toolUse;
    }

    public void setToolUse(ToolUse toolUse) {
        this.toolUse = toolUse;
    }

    public ResultCheckerConfig getResultChecker() {
        return resultChecker;
    }

    public void setResultChecker(ResultCheckerConfig resultChecker) {
        this.resultChecker = resultChecker;
    }

    public Fewshot getFewshot() {
        return fewshot;
    }

    public void setFewshot(Fewshot fewshot) {
        this.fewshot = fewshot;
    }

    public Conversation getConversation() {
        return conversation;
    }

    public void setConversation(Conversation conversation) {
        this.conversation = conversation;
    }

    public Db getDb() {
        return db;
    }

    public void setDb(Db db) {
        this.db = db;
    }

    public Guard getGuard() {
        return guard;
    }

    public void setGuard(Guard guard) {
        this.guard = guard;
    }

    public Llm getLlm() {
        return llm;
    }

    public void setLlm(Llm llm) {
        this.llm = llm;
    }

    public Prompt getPrompt() {
        return prompt;
    }

    public void setPrompt(Prompt prompt) {
        this.prompt = prompt;
    }

    public Retrieval getRetrieval() {
        return retrieval;
    }

    public void setRetrieval(Retrieval retrieval) {
        this.retrieval = retrieval;
    }

    public Semantic getSemantic() {
        return semantic;
    }

    public void setSemantic(Semantic semantic) {
        this.semantic = semantic;
    }

    public Clarification getClarification() {
        return clarification;
    }

    public void setClarification(Clarification clarification) {
        this.clarification = clarification;
    }

    public SelfCorrection getSelfCorrection() {
        return selfCorrection;
    }

    public void setSelfCorrection(SelfCorrection selfCorrection) {
        this.selfCorrection = selfCorrection;
    }

    public Cache getCache() {
        return cache;
    }

    public void setCache(Cache cache) {
        this.cache = cache;
    }

    public Observability getObservability() {
        return observability;
    }

    public void setObservability(Observability observability) {
        this.observability = observability;
    }

    public Routing getRouting() {
        return routing;
    }

    public void setRouting(Routing routing) {
        this.routing = routing;
    }

    public Persistence getPersistence() {
        return persistence;
    }

    public void setPersistence(Persistence persistence) {
        this.persistence = persistence;
    }

    public Eval getEval() {
        return eval;
    }

    public void setEval(Eval eval) {
        this.eval = eval;
    }

    /** 数据库执行护栏：行数上限与超时。属于 ROADMAP 阶段 5 的第一层防线，阶段 1 先落地。 */
    public static class Db {

        /** 结果集最大行数。超过就截断，避免一条 SELECT * 把内存打满。 */
        private int maxRows = 200;

        /** 单条 SQL 的执行超时（秒）。 */
        private int queryTimeoutSeconds = 10;

        public int getMaxRows() {
            return maxRows;
        }

        public void setMaxRows(int maxRows) {
            this.maxRows = maxRows;
        }

        public int getQueryTimeoutSeconds() {
            return queryTimeoutSeconds;
        }

        public void setQueryTimeoutSeconds(int queryTimeoutSeconds) {
            this.queryTimeoutSeconds = queryTimeoutSeconds;
        }
    }

    /**
     * LLM 接入参数。默认走 OpenAI 兼容协议，因此 DeepSeek / 通义千问 / 千帆 / 智谱 /
     * 本地 vLLM 只需要改 base-url、completions-path 和 model，不用改代码。
     *
     * <p>路径也要能配：各家「OpenAI 兼容」兼容的是请求体格式，路径并不统一
     * （通义 /v1/chat/completions，千帆 /v2/chat/completions）。
     */
    public static class Llm {

        private String provider = "openai-compatible";
        private String baseUrl = "https://api.deepseek.com";

        /**
         * 补全端点路径。默认值与 Spring AI 内置的 OpenAI 默认值一致。
         *
         * <p>为什么必须外置：各家「OpenAI 兼容」兼容的是请求体格式，不是路径。
         * 通义是 /v1/chat/completions，千帆是 /v2/chat/completions。
         * 路径也能配，换厂商才真正做到只改配置、不改代码。
         */
        private String completionsPath = "/v1/chat/completions";

        /** 留空则整个应用仍可启动，只是 /api/ask 会返回明确的 503，而不是启动失败。 */
        private String apiKey = "";

        private String model = "deepseek-chat";
        private Double temperature = 0.0;
        private Integer maxTokens = 1024;
        /** provider-default 表示不发送参数；其余值须由目标供应商支持，不能由兼容协议推断。 */
        private String reasoningEffort = "provider-default";
        private int timeoutSeconds = 60;

        /** 成本估算单价（元 / 千 token）。阶段 6 会用真实单价替换，这里先留 0 表示不估算。 */
        private double inputPricePer1k = 0.0;
        private double outputPricePer1k = 0.0;
        /** 缓存命中输入的单价（元 / 千 token）。DeepSeek 空闲价约 0.00002。 */
        private double cacheHitPricePer1k = 0.0;

        public String getProvider() {
            return provider;
        }

        public void setProvider(String provider) {
            this.provider = provider;
        }

        public String getBaseUrl() {
            return baseUrl;
        }

        public void setBaseUrl(String baseUrl) {
            this.baseUrl = baseUrl;
        }

        public String getCompletionsPath() {
            return completionsPath;
        }

        public void setCompletionsPath(String completionsPath) {
            this.completionsPath = completionsPath;
        }

        public String getApiKey() {
            return apiKey;
        }

        public void setApiKey(String apiKey) {
            this.apiKey = apiKey;
        }

        public String getModel() {
            return model;
        }

        public void setModel(String model) {
            this.model = model;
        }

        public Double getTemperature() {
            return temperature;
        }

        public void setTemperature(Double temperature) {
            this.temperature = temperature;
        }

        public Integer getMaxTokens() {
            return maxTokens;
        }

        public void setMaxTokens(Integer maxTokens) {
            this.maxTokens = maxTokens;
        }

        public int getTimeoutSeconds() {
            return timeoutSeconds;
        }

        public String getReasoningEffort() {
            return reasoningEffort;
        }

        public void setReasoningEffort(String value) {
            String normalized = value == null || value.isBlank() ? "provider-default"
                    : value.strip().toLowerCase(java.util.Locale.ROOT);
            if (!java.util.Set.of("provider-default", "none", "low", "high", "max").contains(normalized)) {
                throw new IllegalArgumentException("agent.llm.reasoning-effort must be provider-default, none, low, high or max");
            }
            reasoningEffort = normalized;
        }

        public void setTimeoutSeconds(int timeoutSeconds) {
            this.timeoutSeconds = timeoutSeconds;
        }

        public double getInputPricePer1k() {
            return inputPricePer1k;
        }

        public void setInputPricePer1k(double inputPricePer1k) {
            this.inputPricePer1k = inputPricePer1k;
        }

        public double getOutputPricePer1k() {
            return outputPricePer1k;
        }

        public void setOutputPricePer1k(double outputPricePer1k) {
            this.outputPricePer1k = outputPricePer1k;
        }

        public double getCacheHitPricePer1k() {
            return cacheHitPricePer1k;
        }

        public void setCacheHitPricePer1k(double cacheHitPricePer1k) {
            this.cacheHitPricePer1k = cacheHitPricePer1k;
        }
    }

    /**
     * 校验层的护栏参数。
     *
     * <p>把这些做成配置而不是写死在代码里，是为了能在评估时做消融实验：
     * 精确测量「关掉强制 LIMIT 后准确率与系统开销会发生什么变化」，提供可度量的实证对比。
     */
    public static class Guard {

        /**
         * 没有 LIMIT 时怎么办。
         *
         * <p>APPEND = 自动补上 LIMIT（默认）。REJECT = 直接判定非法。
         *
         * <p>默认选 APPEND 的理由：用户问「所有订单有多少」时模型可能忘了写 LIMIT，
         * 直接拒绝等于把一个能答对的问题判死，用户体验上是纯损失。
         * 补 LIMIT 既保证不拖库，又不牺牲答案。REJECT 模式保留，用于演示
         * 「拦截」这个动作本身——两种模式的行为差异会被写进测试。
         */
        private LimitMode limitMode = LimitMode.APPEND;

        /**
         * 是否启用「列级白名单」（阶段 5）。
         *
         * <p>只校验带表别名前缀的列，例如 {@code o.customer_id}——这类引用能精确
         * 归属到某张表，判定是确定的。裸列名不检查，因为 SELECT 别名、CTE 输出列、
         * 派生表列都可能是合法来源，误判会把正常查询拦下。
         *
         * <p>默认开启：它拦下的是 {@code sellers.region_name} 这种执行时必然报错的
         * 引用，收益确定、误伤面小。要复现阶段 1–4 的历史数字时把它关掉。
         */
        private boolean columnWhitelistEnabled = true;

        public boolean isColumnWhitelistEnabled() {
            return columnWhitelistEnabled;
        }

        public void setColumnWhitelistEnabled(boolean columnWhitelistEnabled) {
            this.columnWhitelistEnabled = columnWhitelistEnabled;
        }

        /**
         * 是否启用 EXPLAIN 预执行与查询计划代价护栏（Cost Guard）。
         */
        private boolean explainCostGuardEnabled = false;

        /**
         * 允许执行的最大估算 Cost（Total Cost）。默认 100,000。超过此阈值触发熔断反思重试。
         */
        private double maxAllowedCost = 100000.0;

        /**
         * 是否拦截未受限的全表笛卡尔积（Cartesian Product）。默认 true。
         */
        private boolean rejectCartesianProduct = true;

        public boolean isExplainCostGuardEnabled() {
            return explainCostGuardEnabled;
        }

        public void setExplainCostGuardEnabled(boolean explainCostGuardEnabled) {
            this.explainCostGuardEnabled = explainCostGuardEnabled;
        }

        public double getMaxAllowedCost() {
            return maxAllowedCost;
        }

        public void setMaxAllowedCost(double maxAllowedCost) {
            this.maxAllowedCost = maxAllowedCost;
        }

        public boolean isRejectCartesianProduct() {
            return rejectCartesianProduct;
        }

        public void setRejectCartesianProduct(boolean rejectCartesianProduct) {
            this.rejectCartesianProduct = rejectCartesianProduct;
        }

        /**
         * 额外禁止的函数名（小写）。
         *
         * <p>列表里的函数都有一个共同点：**只读语句也能造成副作用**。
         * 典型如 pg_read_file 能读服务器任意文件、pg_sleep 能把连接挂死、
         * pg_terminate_backend 能踢掉别的会话。
         * 这类风险单靠「只允许 SELECT」是挡不住的——这是很多人做 Text2SQL
         * 安全时最容易漏掉的一类攻击面。
         */
        private List<String> forbiddenFunctions = new ArrayList<>(List.of(
                "pg_read_file", "pg_read_binary_file", "pg_ls_dir", "pg_stat_file",
                "pg_file_read", "pg_file_write", "pg_file_rename", "pg_file_unlink",
                "pg_ls_logdir", "pg_logdir_ls",
                "pg_sleep", "pg_sleep_for", "pg_sleep_until",
                "pg_terminate_backend", "pg_cancel_backend", "pg_reload_conf", "pg_rotate_logfile",
                "lo_import", "lo_export", "dblink", "dblink_exec",
                "set_config", "nextval", "setval",
                "pg_advisory_lock", "pg_advisory_xact_lock",
                "copy", "pg_stat_reset"));

        public enum LimitMode {
            APPEND,
            REJECT
        }

        public LimitMode getLimitMode() {
            return limitMode;
        }

        public void setLimitMode(LimitMode limitMode) {
            this.limitMode = limitMode;
        }

        public List<String> getForbiddenFunctions() {
            return forbiddenFunctions;
        }

        public void setForbiddenFunctions(List<String> forbiddenFunctions) {
            this.forbiddenFunctions = forbiddenFunctions;
        }
    }

    /**
     * 上下文组装参数。阶段 1 只做「整库塞入」，因此这里只有开关，没有 Top-K。
     * 阶段 2 引入检索后，Top-K / Top-N 会加在这里。
     */
    public static class Prompt {

        /** 单因素消融入口：默认保留四步指令；关闭不改变供应商reasoning_effort。 */
        private boolean explicitReasoningEnabled = true;

        public boolean isExplicitReasoningEnabled() {
            return explicitReasoningEnabled;
        }

        public void setExplicitReasoningEnabled(boolean explicitReasoningEnabled) {
            this.explicitReasoningEnabled = explicitReasoningEnabled;
        }

        /**
         * 是否在上下文里附带数据画像（行数、时间范围）。
         *
         * <p>这是阶段 1 唯一一处「人为加料」，必须显式记录，否则 baseline 数字不可复现。
         * 加它的理由：Olist 数据截止 2018-10，而模型默认会用 current_date 理解「最近 30 天」，
         * 导致 T3 时间层 30 条全部落空。那不是「朴素 baseline」，那是「有缺陷的 baseline」，
         * 会让阶段 2 的增量虚高。开关保留，阶段 6 可以做消融实验量化它的贡献。
         */
        private boolean includeDataProfile = true;

        /** 是否在上下文里附带外键关系。同上，属于 schema 事实而非优化。 */
        private boolean includeForeignKeys = true;

        public boolean isIncludeDataProfile() {
            return includeDataProfile;
        }

        public void setIncludeDataProfile(boolean includeDataProfile) {
            this.includeDataProfile = includeDataProfile;
        }

        public boolean isIncludeForeignKeys() {
            return includeForeignKeys;
        }

        public void setIncludeForeignKeys(boolean includeForeignKeys) {
            this.includeForeignKeys = includeForeignKeys;
        }
    }

    /**
     * 检索层参数（阶段 2）。
     *
     * <p><b>为什么 enabled 默认 false</b>
     *
     * <p>两个理由。一是「优化必须显式开启」：baseline 是验收的参照系，
     * 它必须随时可复现，不能因为某个默认值变了就悄悄变成另一个东西。
     * 二是消融实验需要这个开关——同一份代码、同一个数据库、同一个模型，
     * 只改这一个布尔值，就能得到「+schema 检索」那一行的数字。
     * 如果检索是默认行为，跑 baseline 反而要额外配一堆参数，很容易配错。
     *
     * <p>这些阈值都放在配置里而不是代码常量，是为了能在开发集上做小范围
     * 参数搜索与消融对照——系统设计不仅给出最终数字，更沉淀调优过程与证据链。
     */
    public static class Retrieval {

        /** 是否启用检索版 provider。false = 走阶段 1 的全量 provider（baseline）。 */
        private boolean enabled = false;

        /** 最终交给模型的表数量上限。 */
        private int topK = 8;

        /** 关系扩展跳数。0 = 不扩展；1 = 只带一跳邻居；2 = 两跳。 */
        private int relationHops = 1;

        /** 关系扩展衰减系数。降低扩展分数；不保证弱直接命中高于强种子的扩展项。 */
        private double relationDecay = 0.4;

        /**
         * 最多从几张表出发做关系扩展。
         *
         * <p>不做这个限制的话，一个命中五张表的问题会扩展出十几张表，
         * Top-K 形同虚设。取分数最高的几张出发，是把扩展预算花在
         * 最可信的命中上。
         */
        private int expansionSeedLimit = 3;

        /**
         * 单字别名的权重折扣。
         *
         * <p>「州」「券」「仓」这类单字词召回价值高但误命中率也高
         * （「广州」含「州」、「优惠」含「券」）。打折而不是禁用：
         * 禁用会丢掉「各州的订单量」这类问法，那是真实存在的说法。
         */
        private double singleCharWeightFactor = 0.5;

        /** 英文标识符（表名/列名）直接出现在问题里时的权重。 */
        private double identifierHitWeight = 1.5;

        /**
         * 是否开启「连通性修复」：Top-K 出来的表如果连不成一张图，
         * 自动补入关系图上的最短桥接表。
         *
         * <p>默认开启。它解决的是纯词法检索的结构性盲区——用户问
         * 「每个大区的商品销售额」时不会说「客户」，而 {@code customers}
         * 恰恰是连接 {@code regions} 和 {@code orders} 的唯一通路。
         * 这个缺口补词典补不掉，只能靠图算法。
         */
        private boolean bridgeRepairEnabled = true;

        /**
         * 连通性修复最多额外补几张表。
         *
         * <p>上限存在的意义：多组件子图可能需要引入多张桥接表，
         * 不封顶就会一路补到接近全量，把检索的意义抵消掉。
         * 宁可保留不连通（模型会生成跑不通的 SQL，错误可见），
         * 也不要悄悄把上下文撑爆。取 2 的实测依据：绝大多数
         * 不连通情形只差一张中枢表。
         */
        private int bridgeRepairMaxTables = 2;

        /**
         * 阶段 3：是否在 prompt 里附上「列级 join 关系」。
         *
         * <p><b>默认关闭——这是被实测数字推翻后的决定。</b>
         *
         * <p>阶段 3 的设计假设是「模型不知道该用哪一列 join」。这个假设
         * 本身被验证了：T4-015 问「每个大区的订单量」，gold 写
         * {@code r.region_code = c.customer_state}，模型写成了
         * {@code r.region_name}——两列在 regions 里都存在，SQL 能跑、结果错。
         * 补上这条边之后，T4-015 确实修好了，join 类错误从 4 条降到 1 条。
         *
         * <p>但**整体准确率没有变化**：52% → 52%（100 条 eval，同模型）。
         * 修好 5 条、新坏 5 条，净变化为零。核查新坏的 5 条：
         *
         * <ul>
         *   <li>3 条是单表题（T1-010 / T2-013 / T3-014），压根没有 join，
         *       属于模型自身的随机波动，与本次改动无关；</li>
         *   <li>2 条是**过度 join**（T4-006 / T4-031）：模型看到 JOINS 段里
         *       有 {@code sellers -> regions} 这条边，就把它连上了，
         *       而 gold 不需要它。</li>
         * </ul>
         *
         * <p>代价则是确定的：平均 DDL 从 1579 涨到 2193 字符（+39%），
         * 平均输入 token 从 709 涨到 917（+29%）。
         * **确定成本换不确定收益，工程上不成立，所以默认关闭。**
         *
         * <p>代码保留而不是删除，理由有两个：一是它修好的那类错误是真实的
         * （join 列猜错会静默出错），换一个 join 更密集的数据集时它可能就划算了；
         * 二是「做了优化、测出无效、如实关掉」这件事本身就是可信度的证据，
         * 比删掉痕迹更值得保留。想复现实验：{@code --agent.retrieval.join-hints-enabled=true}。
         */
        private boolean joinHintsEnabled = false;

        /**
         * 是否开启动态列级剪枝（Column-level Pruning）。
         *
         * <p>默认关闭以保持 baseline 纯粹性。开启后，在表级检索的基础上进一步
         * 裁剪每张表的字段，只保留主外键关联列、实体取值列、指标列与提问命中的语义列，
         * 将 Schema Token 压缩 30%~50%，避免多表 Join 时模型注意力被冗余列分散。
         */
        private boolean columnPruningEnabled = false;

        /**
         * 列级剪枝时单张表的保留列数下限（安全兜底，避免过度剪枝）。
         */
        private int columnPruningMinColumns = 4;

        /**
         * 是否渲染 {@code JOINS} 段（全部候选边，含列名）。
         *
         * <p>单独留开关是为了定位「过度 join」的来源。实测怀疑是这一段
         * 让模型看到了太多可用边，于是把不该连的表也连上了。要验证的话：
         * 关掉这一段、只留 {@code JOIN PLAN}，看 T4-006 / T4-031 是否恢复。
         */
        private boolean joinListEnabled = true;

        /**
         * 是否渲染 {@code JOIN PLAN} 段（规划出的连接树）。
         *
         * <p>与 {@link #joinListEnabled} 配合做两段分离的消融：
         * 只给列表、只给树、两个都给，三种组合能定位到底哪一段在起作用。
         */
        private boolean joinPlanEnabled = true;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public int getTopK() {
            return topK;
        }

        public void setTopK(int topK) {
            this.topK = topK;
        }

        public int getRelationHops() {
            return relationHops;
        }

        public void setRelationHops(int relationHops) {
            this.relationHops = relationHops;
        }

        public double getRelationDecay() {
            return relationDecay;
        }

        public void setRelationDecay(double relationDecay) {
            this.relationDecay = relationDecay;
        }

        public int getExpansionSeedLimit() {
            return expansionSeedLimit;
        }

        public void setExpansionSeedLimit(int expansionSeedLimit) {
            this.expansionSeedLimit = expansionSeedLimit;
        }

        public double getSingleCharWeightFactor() {
            return singleCharWeightFactor;
        }

        public void setSingleCharWeightFactor(double singleCharWeightFactor) {
            this.singleCharWeightFactor = singleCharWeightFactor;
        }

        public double getIdentifierHitWeight() {
            return identifierHitWeight;
        }

        public void setIdentifierHitWeight(double identifierHitWeight) {
            this.identifierHitWeight = identifierHitWeight;
        }

        public boolean isBridgeRepairEnabled() {
            return bridgeRepairEnabled;
        }

        public void setBridgeRepairEnabled(boolean bridgeRepairEnabled) {
            this.bridgeRepairEnabled = bridgeRepairEnabled;
        }

        public int getBridgeRepairMaxTables() {
            return bridgeRepairMaxTables;
        }

        public void setBridgeRepairMaxTables(int bridgeRepairMaxTables) {
            this.bridgeRepairMaxTables = bridgeRepairMaxTables;
        }

        public boolean isJoinHintsEnabled() {
            return joinHintsEnabled;
        }

        public void setJoinHintsEnabled(boolean joinHintsEnabled) {
            this.joinHintsEnabled = joinHintsEnabled;
        }

        public boolean isJoinListEnabled() {
            return joinListEnabled;
        }

        public void setJoinListEnabled(boolean joinListEnabled) {
            this.joinListEnabled = joinListEnabled;
        }

        public boolean isJoinPlanEnabled() {
            return joinPlanEnabled;
        }

        public void setJoinPlanEnabled(boolean joinPlanEnabled) {
            this.joinPlanEnabled = joinPlanEnabled;
        }

        public boolean isColumnPruningEnabled() {
            return columnPruningEnabled;
        }

        public void setColumnPruningEnabled(boolean columnPruningEnabled) {
            this.columnPruningEnabled = columnPruningEnabled;
        }

        public int getColumnPruningMinColumns() {
            return columnPruningMinColumns;
        }

        public void setColumnPruningMinColumns(int columnPruningMinColumns) {
            this.columnPruningMinColumns = columnPruningMinColumns;
        }
    }

    /**
     * 业务口径注册表参数（阶段 4）。
     *
     * <p><b>它是什么（先把话说准）</b>
     *
     * <p>它把 {@code metrics.yml} 里人工写好的口径文本按关键词命中后注入 prompt。
     * 全程只有「子串匹配 + 依赖表过滤 + 拼接文本」三步，**不做语义理解、
     * 不生成 SQL、不改写 SQL**；最终 SQL 仍由模型写。
     *
     * <p><b>它解决什么问题</b>
     *
     * <p>阶段 3 的失败归因显示：T6 业务口径题 12 条全错，而且错法高度一致——
     * 不是 SQL 写不出来，是**口径猜错**。实测 25 条 T6 题里 17 条要求
     * 「有效订单」（排除 canceled/unavailable），模型经常忘；GMV 含不含运费、
     * 比例要不要乘 100、时长用整数天还是小数天，模型每次都在猜。
     * 这些信息不在数据库里：表、列、join 能从 schema 读到，但「哪些行算数、
     * 分子分母是谁、输出成什么样」是业务约定。
     *
     * <p><b>与检索层开关的关系</b>
     *
     * <p>两者独立：口径注入可以在全量 schema 下生效（baseline + 口径注入），
     * 也可以和检索一起生效。独立开关是为了能做出干净的四方对照：
     *
     * <pre>
     *   baseline            (retrieval=false, semantic=false)
     *   + 检索              (retrieval=true,  semantic=false)
     *   + 口径注入          (retrieval=false, semantic=true)
     *   + 检索 + 口径注入   (retrieval=true,  semantic=true)   ← 完整形态
     * </pre>
     *
     * <p>默认关闭，与检索开关遵循同一条纪律：baseline 必须随时可复现，
     * 优化要显式开启。
     *
     * <p><b>配置键为什么仍叫 semantic</b>：{@code agent.semantic.enabled} 被
     * application.yml、命令行参数和历史评估报告引用，改名会让历史数字无法复现，
     * 因此保留键名，只在文档里使用「口径注册表」这个准确说法。
     */
    public static class Semantic {

        /** 是否注入业务指标定义。 */
        private boolean enabled = false;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }
    }

    /**
     * 歧义反问参数（阶段 5）。
     *
     * <p><b>它解决什么问题</b>
     *
     * <p>有些问题没有唯一答案，取决于业务口径：「销售额」含不含运费、
     * 「活跃用户」按下单还是按登录。这两种算法都能跑出结果、语法都正确，
     * 因此**没有任何自动信号能发现猜错了**——阶段 5 的自纠错实验证明了这点：
     * 首答 SQL 有效率 100%，整体却只有 70% 上下，差额全是静默错误。
     *
     * <p>既然系统自己发现不了，就只能在不确定时不下结论：把选择权交还给提问的人。
     *
     * <p><b>默认关闭</b>，而且必须关闭：评估集里的题目都写明了口径，
     * 反问会把「本该作答」变成「不作答」，直接压低准确率。
     * 它是给真实用户链路用的能力，不是给离线评估用的。
     */
    public static class Clarification {

        private boolean enabled = false;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }
    }

    /**
     * 持久化连接参数（阶段 6）。
     *
     * <p><b>为什么是第二个数据源，而不是复用业务那个</b>
     *
     * <p>业务数据源连的是 {@code text2sql_ro}——阶段 5 特意改成只读，目的是让
     * 「AST 校验被绕过」的最坏情况止步于「读到不该读的数据」，而不是「删掉业务数据」。
     * 到了阶段 6 要落库，两件事就撞上了：同一个账号既不该也不能写。
     *
     * <p>解法是**按用途拆账号**，而不是给业务账号开写权限：
     * 业务用只读账号，持久化用 {@code text2sql_rw}，而后者只对
     * {@code semantic_cache}、{@code llm_call_log} 以及两张会话表共四张表有权限，
     * 业务表一行都碰不到。
     *
     * <p><b>刻意不注册成 Spring 的 DataSource Bean</b>：容器里出现第二个 DataSource
     * 会让自动配置的 {@code @ConditionalOnSingleCandidate} 失效，主业务数据源反而可能
     * 装配不上——这是多数据源最常见的翻车点。这里在需要的地方按需构造，
     * 两个数据源互不干扰。
     *
     * <p><b>默认关闭</b>：关闭时缓存退化成纯进程内，功能完全正常，只是重启会丢。
     */
    public static class Persistence {

        private boolean enabled = false;
        private String url = "jdbc:postgresql://localhost:5432/olist";
        private String username = "text2sql_rw";
        private String password = "text2sql_rw";

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }
    }

    /**
     * 可观测参数（阶段 6 第 1 条）。
     *
     * <p>把每次模型调用落成一行 JSONL，用于回答「每次调用花了多少」。
     * 不接外部平台的理由见 {@code LlmCallLog} 的类注释。
     */
    public static class Observability {

        private boolean enabled = true;
        private String dir = "reports/llm-calls";

        /**
         * 是否把完整 prompt 与模型回复写进记录。
         *
         * <p><b>默认关闭，这是隐私取舍而不是省事</b>：prompt 里是用户的原始问题，
         * 回复里是生成的 SQL。写进磁盘就是一份不受控的数据副本，
         * 而且会被备份、被打包、被误提交。默认只记规模（字符数、token、耗时、成本），
         * 需要复现某次具体调用时才显式打开。
         */
        private boolean includeContent = false;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public String getDir() {
            return dir;
        }

        public void setDir(String dir) {
            this.dir = dir;
        }

        public boolean isIncludeContent() {
            return includeContent;
        }

        public void setIncludeContent(boolean includeContent) {
            this.includeContent = includeContent;
        }
    }

    /**
     * 分层模型路由参数（阶段 6 第 2 条）。
     *
     * <p><b>为什么是「失败后升级」而不是「让便宜模型做意图识别」</b>
     *
     * <p>ROADMAP 原本写的是「便宜模型负责意图识别、表选择，强模型只负责生成 SQL」。
     * 按这个系统当前的形态，那一层没有活可干：**表选择已经由词法检索承担**
     * （见阶段 2），它是确定性的、零 token、可解释；再让模型做一遍，
     * 等于花钱把一个已经解决的问题重算一次，还得处理两套结果冲突。
     *
     * <p>所以路由改成**升级制**：默认用便宜模型，只有当它产出的 SQL 跑不通
     * （校验拒绝 / 执行失败）时才升级到强模型重试一次。这样省的是「大部分本来就能答对的题」
     * 的模型费用，而把强模型用在**确实需要它**的那部分上。
     *
     * <p>它和自纠错共用同一个重试位置，但目的不同：自纠错是用**同一个模型**看错误信息再试，
     * 路由是**换一个更强的模型**。两个开关同时打开时，重试那一次既换模型也带上错误信息。
     *
     * <p>默认关闭：它不改变单次质量的上界，只改变成本结构，而成本要等单价填好才能算。
     */
    public static class Routing {

        private boolean enabled = false;

        /** 升级时使用的模型名。留空表示不升级，只把重试交给自纠错。 */
        private String escalationModel = "";

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public String getEscalationModel() {
            return escalationModel;
        }

        public void setEscalationModel(String escalationModel) {
            this.escalationModel = escalationModel;
        }
    }

    /**
     * 语义缓存参数（阶段 6）。
     *
     * <p><b>它省的是什么</b>
     *
     * <p>同一个问题被问第二次时，跳过模型调用，直接复用上次生成的 SQL。
     * 省下的是一次 LLM 调用（1–3 秒 + 对应 token），执行时间照花。
     *
     * <p><b>缓存 SQL 而不是结果集</b>：结果集缓存会把过期数据当正确答案返回，
     * 而且没有任何信号能发现——SQL 正确、格式正常，只是数字是旧的。
     * 详见 {@code SemanticCache} 的类注释。
     *
     * <p><b>默认关闭</b>：它不改变单次提问的质量，只影响重复提问的成本，
     * 而评估集里 100 条问题互不重复，开着也测不出任何东西（命中率恒为 0）。
     * 这也是为什么它的收益必须在「含重复提问」的负载上才能量化。
     */
    public static class Cache {

        private boolean enabled = false;

        /**
         * 最多缓存多少条 SQL。超限按 LRU 淘汰。
         *
         * <p>1000 的取法：一条 SQL 约 200–500 字符，加上键，1000 条约 1MB 量级，
         * 内存完全可接受；同时足够覆盖一个团队日常反复问的那批问题。
         */
        private int maxEntries = 1000;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public int getMaxEntries() {
            return maxEntries;
        }

        public void setMaxEntries(int maxEntries) {
            this.maxEntries = maxEntries;
        }
    }

    /**
     * 线上自纠错参数（阶段 5）。
     *
     * <p><b>它和 {@code Eval.selfCorrection*} 的区别</b>
     *
     * <p>这一份管的是**真实请求链路**（{@code /api/ask}）。它只在 SQL 没有成功执行时
     * 重试——校验拒绝、执行报错、模型返回空内容，这些都是推理时真实存在的信号。
     *
     * <p>{@code Eval.selfCorrection*} 管的是离线评估，多了一档
     * {@code ERRORS_AND_MISMATCH}：执行成功但结果不对时也重试。那一档依赖评估器
     * 手里的 gold 结果来触发，线上不存在这个信号，只能当上限实验读。
     *
     * <p><b>为什么默认关闭</b>：实测首答 SQL 有效率已经是 96–100%，
     * 没有多少错误信号可回灌，收益接近 0；而一旦触发，延迟会明显上升。
     * 优化必须显式开启，baseline 才随时可复现——和检索、口径注入同一条纪律。
     */
    public static class SelfCorrection {

        private boolean enabled = false;

        /** 总尝试次数上限，含首次。1 表示不重试。 */
        private int maxAttempts = 1;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public int getMaxAttempts() {
            return maxAttempts;
        }

        public void setMaxAttempts(int maxAttempts) {
            this.maxAttempts = maxAttempts;
        }
    }

    /**
     * Few-shot 动态示例选择参数（阶段 A）。
     */
    public static class Fewshot {

        /** 是否启用 Few-shot 动态示例注入。默认 false，保持 baseline 干净。 */
        private boolean enabled = false;

        /** 最多注入的示例数量。 */
        private int maxExamples = 3;

        /** Opt-in candidate: never use an example that references tables absent from the request context. */
        private boolean requireAvailableTables = false;

        public boolean isRequireAvailableTables() { return requireAvailableTables; }

        public void setRequireAvailableTables(boolean requireAvailableTables) {
            this.requireAvailableTables = requireAvailableTables;
        }

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public int getMaxExamples() {
            return maxExamples;
        }

        public void setMaxExamples(int maxExamples) {
            this.maxExamples = maxExamples;
        }
    }

    /**
     * 启发式结果校验参数（阶段 B）。
     */
    public static class ResultCheckerConfig {

        /** 是否启用启发式结果校验与自纠错联动。默认 false。 */
        private boolean enabled = false;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }
    }

    /**
     * 智能体工具调用参数（阶段 C）。
     */
    public static class ToolUse {

        /** 是否启用 Agent 工具侦察模式。默认 false。 */
        private boolean enabled = false;

        /** 当涉及表数量达到或超过该阈值时才触发 Agent 侦察模式，简单题走快速生成。 */
        private int tableThreshold = 3;

        /** 最大工具交互轮次。 */
        private int maxRounds = 3;

        /**
         * 是否强制第一轮必须先调用工具侦察。
         *
         * <p>默认 false。实测强制之后 100 题准确率从 85% 掉到 81%：简单题被拖去
         * 查不必要的东西，反而把原本正确的答案改坏（8 条变错、4 条变对）。
         * 只有真正需要侦察的场景才该付出这个代价，所以默认交给模型自己判断。
         */
        private boolean forceFirstInvestigation = false;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public int getTableThreshold() {
            return tableThreshold;
        }

        public void setTableThreshold(int tableThreshold) {
            this.tableThreshold = tableThreshold;
        }

        public boolean isForceFirstInvestigation() {
            return forceFirstInvestigation;
        }

        public void setForceFirstInvestigation(boolean forceFirstInvestigation) {
            this.forceFirstInvestigation = forceFirstInvestigation;
        }

        public int getMaxRounds() {
            return maxRounds;
        }

        public void setMaxRounds(int maxRounds) {
            this.maxRounds = maxRounds;
        }
    }

    /**
     * 阶段 D：多轮对话记忆与指代消解配置。
     *
     * <p>会话期间纯内存缓存加速，会话结束时落库持久化。
     */
    public static class Conversation {

        private boolean enabled = false;
        private int maxTurns = 5;
        private int timeoutMinutes = 30;
        private boolean reuseSchema = true;
        private boolean rewriteWithLlm = true;
        private boolean summaryCompressionEnabled = true;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public int getMaxTurns() {
            return maxTurns;
        }

        public void setMaxTurns(int maxTurns) {
            this.maxTurns = maxTurns;
        }

        public int getTimeoutMinutes() {
            return timeoutMinutes;
        }

        public void setTimeoutMinutes(int timeoutMinutes) {
            this.timeoutMinutes = timeoutMinutes;
        }

        public boolean isReuseSchema() {
            return reuseSchema;
        }

        public void setReuseSchema(boolean reuseSchema) {
            this.reuseSchema = reuseSchema;
        }

        public boolean isRewriteWithLlm() {
            return rewriteWithLlm;
        }

        public void setRewriteWithLlm(boolean rewriteWithLlm) {
            this.rewriteWithLlm = rewriteWithLlm;
        }

        public boolean isSummaryCompressionEnabled() {
            return summaryCompressionEnabled;
        }

        public void setSummaryCompressionEnabled(boolean summaryCompressionEnabled) {
            this.summaryCompressionEnabled = summaryCompressionEnabled;
        }
    }


    /** 评估运行器参数。默认关闭，避免正常启动时误跑 200 条评估。 */
    public static class Eval {

        private boolean enabled = false;
        private String dir = "data/eval";

        /** Optional frozen suite manifest; checked before Gold or paid model calls. */
        private String suiteManifest = "";
        private String outDir = "reports";

        /** 0 表示全部跑；阶段 1 验收用 50。 */
        private int limit = 0;

        /** 留空表示全部难度层；例如 [T1, T2] 只跑前两层。 */
        private List<String> layers = new ArrayList<>();

        /**
         * 开发集 / 评估集切分：{@code all} / {@code dev} / {@code eval}。
         *
         * <p><b>为什么需要它</b>
         *
         * <p>ROADMAP 5.5 的第一条硬原则是「评估集不能用来调参」。
         * 如果只有一份 200 条的数据集，那么「看失败案例 → 补词典 →
         * 重跑同一批 200 条」这个循环跑上几轮之后，报出来的召回率就是
         * 对这批样本过拟合的结果，不再代表真实能力。
         *
         * <p>默认 {@code all}：阶段 1 的历史数字是在全部 200 条上跑的，
         * 默认值改成 {@code dev} 会让「同一条命令的数字变了」，
         * 破坏历史可比性。要分集训练时必须显式写 {@code --agent.eval.split=dev}。
         */
        private String split = "all";

        /**
         * 自检模式：用 gold_sql 冒充模型输出跑一遍评估。
         *
         * <p>作用是把「评估器本身有 bug」和「模型不准」这两件事分开。
         * 如果 dry-run 都跑不到 100%，说明问题在评估器，此时任何准确率数字都不可信。
         * 这是评估体系建设里最容易被跳过、也最值得讲的一步。
         */
        private boolean dryRun = false;

        /**
         * 把评估集重复跑几遍。默认 1（不重复）。
         *
         * <p><b>为什么需要它</b>：阶段 6 要量化语义缓存的收益，而评估集里
         * 100 条问题**互不重复**，缓存命中率必然是 0——标准评估根本测不出这件事。
         * 设成 2 就得到一份「含 50% 重复提问」的负载，命中率、省下的 token、
         * 省下的延迟才能被量出来。
         *
         * <p>注意这不是「多跑几遍取平均」，而是**故意构造重复负载**，
         * 两者目的不同：前者降低噪声，后者模拟真实使用（同一批看板问题被反复问）。
         */
        private int repeat = 1;

        /** 阶段 5：评估中是否启用自纠错重试。默认关闭，保持已有基线可复现。 */
        private boolean selfCorrectionEnabled = false;

        private int selfCorrectionMaxAttempts = 1;

        /**
         * 自纠错的触发条件。
         *
         * <p><b>为什么必须把触发条件和重试内容分开</b>
         *
         * <p>{@link #ERRORS_ONLY} 是**线上真实可用**的：SQL 被校验层拒绝，或数据库
         * 执行报错，这两个信号在推理时确实存在，把它们回传给模型是合法的自纠错。
         *
         * <p>{@link #ERRORS_AND_MISMATCH} 是**评估专用**的：SQL 执行成功但答案不对时，
         * 线上并没有「答案错了」这个信号，只有评估器知道（它手里有 gold_sql）。
         * 所以它测的不是线上能力，而是**上限**——「如果有一个完美的结果校验器，
         * 自纠错还能再救回多少条」。报告里必须标明用的是哪一种，否则这个数字
         * 会被误读成线上收益。
         *
         * <p>注意两者的**反馈内容完全相同**：都只包含数据库真实报错、模型自己上一条
         * SQL 和它自己的结果，绝不包含 gold_sql 或标准答案的任何内容。
         */
        public enum SelfCorrectionTrigger {
            /** 只在执行/校验失败时重试。线上可复现。 */
            ERRORS_ONLY,
            /** 执行成功但结果不匹配时也重试。评估专用，测上限。 */
            ERRORS_AND_MISMATCH
        }

        private SelfCorrectionTrigger selfCorrectionTrigger = SelfCorrectionTrigger.ERRORS_ONLY;

        /**
         * 评估跑完后是否退出进程。默认 true。
         *
         * <p>这是踩过坑才加上的开关：评估器是 {@code ApplicationRunner}，
         * 跑完业务逻辑后 Spring Boot 会继续守着 Web 服务不退出。
         * 结果就是「第一次跑评估正常，第二次启动报 8080 端口被占用」——
         * 因为上一次的进程还在后台活着。批处理任务必须自己结束，
         * 否则每次跑评估前都要手工杀进程，这个坑迟早会浪费掉半小时。
         *
         * <p>留 false 的用途：跑完评估后想接着用 {@code /api/ask} 手工问几句，
         * 这时需要服务继续活着。
         */
        private boolean exitAfterRun = true;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public String getDir() {
            return dir;
        }

        public void setDir(String dir) {
            this.dir = dir;
        }

        public String getSuiteManifest() { return suiteManifest; }

        public void setSuiteManifest(String suiteManifest) { this.suiteManifest = suiteManifest; }

        public String getOutDir() {
            return outDir;
        }

        public void setOutDir(String outDir) {
            this.outDir = outDir;
        }

        public int getLimit() {
            return limit;
        }

        public void setLimit(int limit) {
            this.limit = limit;
        }

        public List<String> getLayers() {
            return layers;
        }

        public void setLayers(List<String> layers) {
            this.layers = layers;
        }

        public String getSplit() {
            return split;
        }

        public void setSplit(String split) {
            this.split = split;
        }

        public boolean isDryRun() {
            return dryRun;
        }

        public void setDryRun(boolean dryRun) {
            this.dryRun = dryRun;
        }

        public int getRepeat() {
            return repeat;
        }

        public void setRepeat(int repeat) {
            this.repeat = repeat;
        }

        public boolean isSelfCorrectionEnabled() {
            return selfCorrectionEnabled;
        }

        public void setSelfCorrectionEnabled(boolean selfCorrectionEnabled) {
            this.selfCorrectionEnabled = selfCorrectionEnabled;
        }

        public int getSelfCorrectionMaxAttempts() {
            return selfCorrectionMaxAttempts;
        }

        public void setSelfCorrectionMaxAttempts(int selfCorrectionMaxAttempts) {
            this.selfCorrectionMaxAttempts = selfCorrectionMaxAttempts;
        }

        public SelfCorrectionTrigger getSelfCorrectionTrigger() {
            return selfCorrectionTrigger;
        }

        public void setSelfCorrectionTrigger(SelfCorrectionTrigger selfCorrectionTrigger) {
            this.selfCorrectionTrigger = selfCorrectionTrigger;
        }

        public boolean isExitAfterRun() {
            return exitAfterRun;
        }

        public void setExitAfterRun(boolean exitAfterRun) {
            this.exitAfterRun = exitAfterRun;
        }
    }
}
