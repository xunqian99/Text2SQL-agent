package com.text2sql.agent.orchestrator;

import com.text2sql.agent.execution.QueryResult;
import com.text2sql.agent.budget.RequestBudget;
import com.text2sql.agent.budget.RequestBudgetRunner;
import com.text2sql.agent.execution.SqlExecutionException;
import com.text2sql.agent.execution.SqlExecutor;
import com.text2sql.agent.generation.GeneratedSql;
import com.text2sql.agent.generation.GenerationException;
import com.text2sql.agent.generation.LlmSqlGenerator;
import com.text2sql.agent.observability.LlmCallRecord;
import com.text2sql.agent.observability.EvaluationTrace;
import com.text2sql.agent.retrieval.SchemaContext;
import com.text2sql.agent.retrieval.SchemaProvider;
import com.text2sql.agent.validation.CheckResult;
import com.text2sql.agent.validation.SqlValidator;
import com.text2sql.agent.validation.ValidationResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import com.text2sql.agent.session.ConversationSession;
import com.text2sql.agent.session.ConversationTurn;
import com.text2sql.agent.session.SessionStore;
import com.text2sql.agent.session.QuestionRewriter;

/**
 * 编排层：把「检索 → 生成 → 校验 → 执行」四步串成一条链路。
 *
 * <p>对应 ROADMAP 第 4 节阶段 1，也对应 3.1 完整链路图里的 [3][6][7][8] 四步。
 * 上游是接入层传来的自然语言问题，下游把 {@link AgentResponse} 交给接入层，
 * 或者交给评估运行器。
 *
 * <p><b>为什么需要一个独立的编排类，而不是把这些逻辑写进 Controller</b>
 *
 * <p>因为这个项目有两个入口：HTTP 接口和离线评估运行器。它们需要的是
 * **完全相同**的链路——如果编排逻辑写在 Controller 里，评估运行器要么
 * 走 HTTP 绕一圈（慢、还要起服务），要么把链路复制一遍（两份实现必然分叉）。
 * 抽成 Service 之后，两个入口共用同一条链路，评估测出来的就是线上真实行为。
 * 这是「评估可信」的结构性前提，比任何测试都重要。
 *
 * <p><b>为什么阶段 1 不做重试</b>
 *
 * <p>重试是阶段 5 的内容，而且它必须建立在「失败已被正确分类」之上：
 * 只有先能区分「表选错」「语法错」「超时」，重试才有明确的修复方向。
 * 阶段 1 先把每一类失败如实记录下来，用 baseline 数字量化它们各占多少。
 * 如果现在就加一个「失败就重试」的循环，baseline 会变得无法解释——
 * 分不清准确率的提升来自模型变强还是来自多试了几次。
 */
@Service
public class Text2SqlOrchestrator {

    private static final Logger log = LoggerFactory.getLogger(Text2SqlOrchestrator.class);

    private final SchemaProvider schemaProvider;
    private final LlmSqlGenerator generator;
    private final SqlValidator validator;
    private final SqlExecutor executor;
    private final com.text2sql.agent.clarification.AmbiguityDetector ambiguityDetector;
    private final com.text2sql.agent.cache.SemanticCache cache;
    private final com.text2sql.agent.validation.ResultChecker resultChecker;
    private final com.text2sql.agent.tool.AgentLoop agentLoop;
    private final com.text2sql.agent.session.SessionStore sessionStore;
    private final com.text2sql.agent.session.QuestionRewriter questionRewriter;
    private final com.text2sql.agent.execution.QueryPlanAnalyzer queryPlanAnalyzer;
    private final com.text2sql.agent.session.SessionContextCompressor sessionContextCompressor = new com.text2sql.agent.session.SessionContextCompressor();
    private final com.text2sql.agent.config.AgentProperties properties;

    @org.springframework.beans.factory.annotation.Autowired
    public Text2SqlOrchestrator(SchemaProvider schemaProvider, LlmSqlGenerator generator,
                                SqlValidator validator, SqlExecutor executor,
                                com.text2sql.agent.clarification.AmbiguityDetector ambiguityDetector,
                                com.text2sql.agent.cache.SemanticCache cache,
                                com.text2sql.agent.validation.ResultChecker resultChecker,
                                com.text2sql.agent.tool.AgentLoop agentLoop,
                                com.text2sql.agent.session.SessionStore sessionStore,
                                com.text2sql.agent.session.QuestionRewriter questionRewriter,
                                com.text2sql.agent.execution.QueryPlanAnalyzer queryPlanAnalyzer,
                                com.text2sql.agent.config.AgentProperties properties) {
        this.schemaProvider = schemaProvider;
        this.generator = generator;
        this.validator = validator;
        this.executor = executor;
        this.ambiguityDetector = ambiguityDetector;
        this.cache = cache;
        this.resultChecker = resultChecker;
        this.agentLoop = agentLoop;
        this.sessionStore = sessionStore;
        this.questionRewriter = questionRewriter;
        this.queryPlanAnalyzer = queryPlanAnalyzer;
        this.properties = properties;
    }

    public Text2SqlOrchestrator(SchemaProvider schemaProvider, LlmSqlGenerator generator,
                                SqlValidator validator, SqlExecutor executor,
                                com.text2sql.agent.clarification.AmbiguityDetector ambiguityDetector,
                                com.text2sql.agent.cache.SemanticCache cache,
                                com.text2sql.agent.validation.ResultChecker resultChecker,
                                com.text2sql.agent.tool.AgentLoop agentLoop,
                                com.text2sql.agent.session.SessionStore sessionStore,
                                com.text2sql.agent.session.QuestionRewriter questionRewriter,
                                com.text2sql.agent.config.AgentProperties properties) {
        this(schemaProvider, generator, validator, executor, ambiguityDetector, cache,
                resultChecker, agentLoop, sessionStore, questionRewriter, null, properties);
    }

    public Text2SqlOrchestrator(SchemaProvider schemaProvider, LlmSqlGenerator generator,
                                SqlValidator validator, SqlExecutor executor,
                                com.text2sql.agent.clarification.AmbiguityDetector ambiguityDetector,
                                com.text2sql.agent.cache.SemanticCache cache,
                                com.text2sql.agent.validation.ResultChecker resultChecker,
                                com.text2sql.agent.tool.AgentLoop agentLoop,
                                com.text2sql.agent.config.AgentProperties properties) {
        this(schemaProvider, generator, validator, executor, ambiguityDetector, cache,
                resultChecker, agentLoop, new com.text2sql.agent.session.SessionStore(properties),
                new com.text2sql.agent.session.QuestionRewriter(generator, properties), null, properties);
    }

    /**
     * 跑完整链路。
     *
     * <p>注意这个方法**不抛异常**。所有失败都被翻译成带 {@code status} 的
     * {@link AgentResponse}。原因是评估运行器要连续跑 200 条，任何一条抛异常
     * 都会中断整轮评估；而且「失败类型」本身就是要统计的数据，用异常
     * 传递会迫使调用方写一串 catch，把分类逻辑散到各处。
     */
    /**
     * 跑完整链路（单轮无会话模式）。
     */
    public AgentResponse ask(String question) {
        return ask(question, null);
    }

    /**
     * 跑完整链路（支持多轮会话记忆、指代消解与 Schema 复用）。
     *
     * <p>注意这个方法**不抛异常**。所有失败都被翻译成带 {@code status} 的
     * {@link AgentResponse}。
     *
     * @param question  用户问题原文
     * @param sessionId 会话 ID，为 null 时以单轮模式运行
     */
    public AgentResponse ask(String question, String sessionId) {
        return ask(question, sessionId, null);
    }

    /**
     * 主业务入口：输入自然语言，经过「歧义澄清/检索/缓存/生成/安全校验/自纠错/执行」全链路。
     * 支持传入自定义 API Key（BYOK 模式）。
     *
     * @param question  用户问题原文
     * @param sessionId 会话 ID，为 null 时以单轮模式运行
     * @param apiKey    用户个人 API Key，为 null 时使用系统全局 Key
     */
    public AgentResponse ask(String question, String sessionId, String apiKey) {
        return ask(question, sessionId, apiKey, false);
    }

    public AgentResponse ask(String question, String sessionId, String apiKey, boolean endSession) {
        // Capture this exact session generation before worker admission. A late worker must never
        // re-create a deleted/reopened session or append its abandoned candidate answer.
        ConversationSession session = properties.getConversation().isEnabled()
                && sessionId != null && !sessionId.isBlank() ? sessionStore.getOrCreate(sessionId) : null;
        var conversation = new ConversationOutcome(session, question);
        return RequestBudgetRunner.run(question, sessionId, properties.getRequestBudget(),
                () -> {
                    AgentResponse response = askPipeline(question, sessionId, apiKey, conversation);
                    RequestBudget.stage("CONVERSATION");
                    var budget = RequestBudget.current();
                    response = budget == null ? conversation.finish(response) : budget.completeOutcome(response);
                    if (endSession && sessionId != null) {
                        RequestBudget.checkpoint(response);
                        RequestBudget.stage("SESSION_PERSIST");
                        closeSession(sessionId);
                    }
                    return response;
                }, conversation::finish);
    }

    private AgentResponse askPipeline(String question, String sessionId, String apiKey, ConversationOutcome conversation) {
        long totalStarted = System.nanoTime();
        RequestBudget.stage("SESSION");

        ConversationSession session = conversation.session;
        boolean convEnabled = session != null;

        String effectiveQuestion = question;
        String rewrittenQuestion = null;
        boolean schemaReused = false;
        SchemaContext schema = null;
        long retrievalMs = 0;
        long rewriteMs = 0;
        com.text2sql.agent.observability.LlmCallRecord rewriteCall = null;

        if (convEnabled && questionRewriter.isFollowUp(question, session)) {
            RequestBudget.stage("REWRITE");
            var rewriteOutcome = questionRewriter.rewriteWithOutcome(question, session);
            rewrittenQuestion = rewriteOutcome.question();
            effectiveQuestion = rewrittenQuestion;
            rewriteCall = rewriteOutcome.call();
            rewriteMs = rewriteOutcome.latencyMs();
            if (questionRewriter.canReuseSchema(question, session) && session.lastSchema() != null) {
                schema = session.lastSchema();
                schemaReused = true;
                log.info("多轮会话复用上一轮 SchemaContext，涉及表: {}", schema.tableNames());
            }
            conversation.metadata = new ConversationMetadata(rewrittenQuestion, schemaReused, schema);
        }

        // 阶段 5：口径没定就先问，不要猜。
        // 放在最前面，是因为它要在花掉一次模型调用之前生效。
        RequestBudget.stage("CLARIFICATION");
        if (properties.getClarification().isEnabled()) {
            var prompt = ambiguityDetector.clarificationFor(effectiveQuestion);
            if (prompt.isPresent()) {
                log.info("问题存在口径歧义，主动反问：{}", prompt.get());
                AgentResponse clar = AgentResponse.clarification(question, prompt.get());
                if (convEnabled) {
                    return clar.withConversation(sessionId, rewrittenQuestion, schemaReused);
                }
                return clar;
            }
        }

        if (schema == null) {
            RequestBudget.stage("RETRIEVAL");
            long retrievalStarted = System.nanoTime();
            schema = schemaProvider.provide(effectiveQuestion);
            retrievalMs = elapsedMs(retrievalStarted);
        }

        int tableCount = schema.tables().size();
        RequestBudget.schema(schema);
        conversation.metadata = new ConversationMetadata(rewrittenQuestion, schemaReused, schema);
        List<String> retrievedTables = schema.tableNames();
        int ddlChars = schema.ddlText() == null ? 0 : schema.ddlText().length();

        // 阶段 6：语义缓存。命中就跳过模型调用，直接拿旧 SQL 走校验和执行。
        RequestBudget.stage("CACHE");
        String cacheKey = cache.enabled() ? cache.key(effectiveQuestion, cacheSignature()) : null;
        if (cacheKey != null) {
            var cachedSql = cache.get(cacheKey);
            if (cachedSql.isPresent()) {
                log.info("语义缓存命中，跳过模型调用");
                AgentResponse hit = validateAndExecute(question, cachedSql.get(), rewriteCall, schema,
                        tableCount, retrievedTables, ddlChars, retrievalMs, rewriteMs, totalStarted);
                if (hit.success()) {
                    EvaluationTrace.attempt("CACHE_SQL", hit);
                    RequestBudget.checkpoint(hit);
                    if (convEnabled) {
                        return hit.withConversation(sessionId, rewrittenQuestion, schemaReused);
                    }
                    return hit;
                }
                log.warn("缓存中的 SQL 这次没跑通（{}），回退到重新生成", hit.status());
            }
        }

        RequestBudget.stage("GENERATION");
        long generationStarted = System.nanoTime();
        GeneratedSql generated;
        LlmCallRecord retryGenerationCall = null;
        boolean generationRetried = false;
        String generationQuestion = effectiveQuestion;
        if (convEnabled && session != null && session.contextSummary() != null && !session.contextSummary().isEmpty()) {
            generationQuestion = effectiveQuestion + "\n\n" + session.contextSummary().condensedSummaryText();
        }


        try {
            boolean useAgentMode = properties.getToolUse().isEnabled()
                    && tableCount >= properties.getToolUse().getTableThreshold();

            if (useAgentMode) {
                log.info("触发 Agent 侦察工具循环模式（涉及 {} 张表 >= 阈值 {}）",
                        tableCount, properties.getToolUse().getTableThreshold());
                generated = (apiKey != null && !apiKey.isBlank())
                        ? agentLoop.run(generationQuestion, schema, properties.getToolUse().getMaxRounds(), null, apiKey)
                        : agentLoop.run(generationQuestion, schema, properties.getToolUse().getMaxRounds(), null);
            } else {
                generated = (apiKey != null && !apiKey.isBlank())
                        ? generator.generate(generationQuestion, schema, null, apiKey)
                        : generator.generate(generationQuestion, schema);
            }
        } catch (GenerationException e) {
            EvaluationTrace.generationFailure(question, e);
            if (properties.getSelfCorrection().isEnabled() && properties.getSelfCorrection().getMaxAttempts() > 1
                    && e.getReason() != GenerationException.Reason.NOT_CONFIGURED
                    && e.getReason() != GenerationException.Reason.OFF_PEAK_REQUIRED && RequestBudget.allowRetry()) {
                generationRetried = true;
                EvaluationTrace.trigger("GENERATION_" + e.getReason().name());
                log.warn("首次生成异常（{}：{}），尝试重试一次生成", e.getReason(), e.getMessage());
                try {
                    generated = (apiKey != null && !apiKey.isBlank())
                            ? generator.generate(generationQuestion, schema, null, apiKey)
                            : generator.generate(generationQuestion, schema);
                    retryGenerationCall = e.getCallRecord();
                } catch (GenerationException e2) {
                    EvaluationTrace.generationFailure(question, e2);
                    EvaluationTrace.select(2);
                    long generationMs = elapsedMs(generationStarted);
                    AgentResponse.Status status = e2.getReason() == GenerationException.Reason.NOT_CONFIGURED
                            ? AgentResponse.Status.NOT_CONFIGURED
                            : AgentResponse.Status.GENERATION_FAILED;
                    log.warn("重试生成仍失败（{}）：{}", e2.getReason(), e2.getMessage());
                    LlmCallRecord failedCalls = LlmCallRecord.combine(rewriteCall,
                            LlmCallRecord.combine(e.getCallRecord(), e2.getCallRecord()));
                    AgentResponse fail = AgentResponse.failed(question, status, null, e2.getMessage(), failedCalls,
                            tableCount, retrievedTables, ddlChars,
                            timings(retrievalMs, generationMs, 0, 0, elapsedMs(totalStarted)));
                    if (convEnabled) {
                        return fail.withConversation(sessionId, rewrittenQuestion, schemaReused);
                    }
                    return fail;
                }
            } else {
                long generationMs = elapsedMs(generationStarted);
                AgentResponse.Status status = e.getReason() == GenerationException.Reason.NOT_CONFIGURED
                        ? AgentResponse.Status.NOT_CONFIGURED
                        : AgentResponse.Status.GENERATION_FAILED;
                log.warn("生成失败（{}）：{}", e.getReason(), e.getMessage());
                LlmCallRecord failedCalls = LlmCallRecord.combine(rewriteCall, e.getCallRecord());
                AgentResponse fail = AgentResponse.failed(question, status, null, e.getMessage(), failedCalls,
                        tableCount, retrievedTables, ddlChars,
                        timings(retrievalMs, generationMs, 0, 0, elapsedMs(totalStarted)));
                if (convEnabled) {
                    return fail.withConversation(sessionId, rewrittenQuestion, schemaReused);
                }
                return fail;
            }
        }
        long generationMs = elapsedMs(generationStarted) + rewriteMs;

        // 把「多轮改写」那次调用的账并进本轮的生成账目。
        // 改写是一次真实的模型调用：不合并的话，token 与成本每轮都会少算一次，
        // 表现为「报告里的成本和实际账单对不上，差得不多但总有差值」。
        AgentResponse first = validateAndExecute(question, generated.sql(),
                LlmCallRecord.combine(rewriteCall, LlmCallRecord.combine(retryGenerationCall, generated.call())),
                schema, tableCount, retrievedTables, ddlChars, retrievalMs, generationMs, totalStarted);
        EvaluationTrace.attempt("INITIAL_SQL", first);
        RequestBudget.checkpoint(first);
        if (generationRetried) EvaluationTrace.select(2);
        AgentResponse result = generationRetried ? first : retryIfFailed(generationQuestion, first, apiKey);

        RequestBudget.stage("CACHE_WRITE");
        if (cacheKey != null && result.success()) {
            cache.put(cacheKey, result.sql());
        }

        if (convEnabled) {
            return result.withConversation(sessionId, rewrittenQuestion, schemaReused);
        }

        return result;
    }

    public Optional<ConversationSession> closeSession(String sessionId) {
        return sessionStore.closeAndPersist(sessionId);
    }

    public List<SessionStore.SessionSummary> listSessions() {
        return sessionStore.listSessions();
    }

    public boolean deleteSession(String sessionId) {
        return sessionStore.deleteSession(sessionId);
    }

    public SessionStore getSessionStore() {
        return sessionStore;
    }

    private record ConversationMetadata(String rewrittenQuestion, boolean schemaReused, SchemaContext schema) { }

    /** Payload selection owns the only history write; metadata updates alone never mutate a session. */
    private final class ConversationOutcome {
        private final ConversationSession session;
        private final String question;
        private volatile ConversationMetadata metadata = new ConversationMetadata(null, false, null);
        private AgentResponse selected;

        private ConversationOutcome(ConversationSession session, String question) {
            this.session = session;
            this.question = question;
        }

        private synchronized AgentResponse finish(AgentResponse response) {
            if (selected != null) return selected;
            if (session == null) return selected = response;
            var snapshot = metadata;
            selected = response.withConversation(session.sessionId(), snapshot.rewrittenQuestion(), snapshot.schemaReused());
            // Do not revive deleted sessions or inject an old completion into a new generation.
            if (sessionStore.get(session.sessionId()).orElse(null) == session && !session.isClosed()) {
                synchronized (session) {
                    if (selected.success() && snapshot.schema() != null) session.setLastSchema(snapshot.schema());
                    recordConversationTurn(session, question, snapshot.rewrittenQuestion(), selected);
                }
            }
            return selected;
        }
    }

    private void recordConversationTurn(ConversationSession session, String rawQuestion,
                                        String rewrittenQuestion, AgentResponse response) {
        if (session == null) {
            return;
        }
        String summary = summarizeResponse(response);
        ConversationTurn turn = ConversationTurn.of(
                session.turns().size() + 1,
                rawQuestion,
                rewrittenQuestion != null ? rewrittenQuestion : rawQuestion,
                response.sql(),
                response.status().name(),
                summary
        );
        if (properties.getConversation().isSummaryCompressionEnabled()) {
            session.addTurn(turn, properties.getConversation().getMaxTurns(), sessionContextCompressor);
        } else {
            session.addTurn(turn, properties.getConversation().getMaxTurns());
        }

    }

    private String summarizeResponse(AgentResponse response) {
        if (!response.success()) {
            return response.status().name() + (response.message() != null ? ": " + response.message() : "");
        }
        int count = response.rowCount();
        if (count == 0) {
            return "0 行数据";
        }
        List<String> cols = response.columns();
        String colsDesc = (cols == null || cols.isEmpty()) ? "" : String.join(", ", cols);
        String preview = "";
        if (response.rows() != null && !response.rows().isEmpty()) {
            preview = " 样例: " + response.rows().get(0).toString();
        }
        return "共 " + count + " 行数据 (列: " + colsDesc + ")" + preview;
    }

    /**
     * 配置指纹。
     *
     * <p>把「改了它，同一个问题就该得到不同 SQL」的开关都编进来：模型、prompt 版本、
     * 检索开关与 Top-K、join 提示/清单/规划、桥接修复、列剪枝、口径注入、
     * few-shot、数据画像/外键注入、工具侦察、LIMIT 模式、升级路由。
     *
     * <p>漏掉任何一个的后果都一样且难查：改了配置，旧答案继续被命中，
     * 表现成「配置改了但数字一点没动」。历史评估报告里因此一直记着 prompt 版本，
     * 这里用的是同一个理由。
     *
     * <p><b>这里踩过一次真实的坑</b>：最初只编了 retrieval.enabled/top-k、
     * semantic.enabled、limit 模式和路由，漏了 join 提示、列剪枝、few-shot、
     * 数据画像与外键、工具侦察这几类。结果是「打开 few-shot 重跑消融，数字纹丝不动」——
     * 因为命中的全是关掉 few-shot 时缓存下来的 SQL。评估里最难发现的错误就是这种：
     * 报告格式完全正常，只是数字是上一次配置的。
     *
     * <p>加字段的原则：**只要它会影响模型看到的内容或最终 SQL 的形状，就必须进指纹**。
     */
    String cacheSignature() {
        var retrieval = properties.getRetrieval();
        var prompt = properties.getPrompt();
        var fewshot = properties.getFewshot();
        var toolUse = properties.getToolUse();
        var guard = properties.getGuard();
        var routing = properties.getRouting();
        return "%s|%s|r=%b:%d:%b:%b:%b:%b|prune=%b|s=%b|metrics=%s|fs=%b:%d:%s|dp=%b|fk=%b|tu=%b|limit=%s:%d|esc=%s"
                .formatted(
                        properties.getLlm().getModel(),
                        com.text2sql.agent.generation.PromptTemplate.versionFor(properties),
                        retrieval.isEnabled(),
                        retrieval.getTopK(),
                        retrieval.isJoinHintsEnabled(),
                        retrieval.isJoinListEnabled(),
                        retrieval.isJoinPlanEnabled(),
                        retrieval.isBridgeRepairEnabled(),
                        retrieval.isColumnPruningEnabled(),
                        properties.getSemantic().isEnabled(),
                        // Global snapshot invalidates even persistent SQL cached under an older business definition.
                        properties.getSemantic().isEnabled()
                                ? com.text2sql.agent.semantic.MetricRegistry.definitionSha256() : "-",
                        fewshot.isEnabled(),
                        fewshot.getMaxExamples(),
                        fewshot.isEnabled() ? com.text2sql.agent.fewshot.ExampleSelector.policyVersion(
                                fewshot.isRequireAvailableTables()) : "-",
                        prompt.isIncludeDataProfile(),
                        prompt.isIncludeForeignKeys(),
                        toolUse.isEnabled(),
                        guard.getLimitMode().name(),
                        // max-rows 也要进指纹：APPEND 模式下补的 LIMIT 就是由它算出来的，
                        // 改了它缓存里的旧 SQL 仍然带着旧上限。
                        properties.getDb().getMaxRows(),
                        routing.isEnabled() ? routing.getEscalationModel() : "-");
    }

    /**
     * 线上自纠错：第一次没成功执行时，把真实错误回灌给模型再试一次。
     *
     * <p><b>只在「有错误信号」时重试</b>。这里判断的是 {@code !success()}，
     * 也就是校验拒绝 / 执行失败 / 模型返回空内容——这三类都是推理时确实存在的信息。
     * 而「执行成功但答案不对」在线上没有信号，所以这里**不重试**，
     * 那一档只能放在评估器里当上限实验（见 {@code Eval.selfCorrectionTrigger}）。
     *
     * <p><b>重试失败时保留首次结果</b>。这是刻意的：把一次糟糕的重试当成最终答案，
     * 会让系统的表现比不重试更差——实测里出现过「首次能跑通、重试反而执行失败」
     * 的情况。所以只有第二次**成功**才用它，否则原样返回第一次的结果。
     *
     * <p><b>第二次成功也不等于更好</b>。首次是「执行成功但被启发式规则判可疑」时，
     * 第二次必须**也通过同一套校验**才配替换；否则保留首次。没有这一步，
     * 一次规则误报就会把本来正确的答案换成错的（比率越界规则上真实发生过）。
     *
     * <p>代价必须可查：{@code combineAttempts} 会把两次调用的 token 和延迟相加，
     * 这样「每次调用花了多少」这个数字不会被重试悄悄稀释。
     */
    private AgentResponse retryIfFailed(String question, AgentResponse first, String apiKey) {
        RequestBudget.stage("RESULT_CHECK");
        var config = properties.getSelfCorrection();
        var routing = properties.getRouting();
        boolean escalate = routing.isEnabled() && !routing.getEscalationModel().isBlank();
        boolean retryAllowed = (config.isEnabled() && config.getMaxAttempts() > 1) || escalate;

        boolean shouldRetry = false;
        String feedback = null;
        // 首次「执行成功但结果可疑」时记录命中的规则，供重试后的择优判定使用。
        // 首次是执行/校验失败时保持 null：那种情况下第二次只要能跑通就一定更好，无需再比。
        String firstSuspicion = null;

        if (retryAllowed) {
            if (!first.success()) {
                shouldRetry = true;
                feedback = retryFeedback(first);
            } else if (properties.getResultChecker().isEnabled()) {
                // 阶段 B：启发式结果校验
                QueryResult qr = new QueryResult(first.columns(), first.rows(), first.truncated(), 0L);
                var check = resultChecker.check(question, first.sql(), qr);
                if (check.suspicious()) {
                    shouldRetry = true;
                    firstSuspicion = check.rule();
                    log.info("启发式结果校验命中异常（规则：{}）：{}", check.rule(), check.reason());
                    feedback = correctionFeedback(question, first, check);
                }
            }
        }

        if (!shouldRetry || !RequestBudget.allowRetry()) {
            return first;
        }
        EvaluationTrace.trigger(firstSuspicion == null ? first.status().name() : firstSuspicion);

        // 阶段 6：路由开启时换强模型重试。两个开关的作用不同——
        // 自纠错是「同一个模型看错误信息再试」，路由是「换一个更强的模型」。
        // 同时打开时这次重试两者兼具。
        String model = escalate ? routing.getEscalationModel() : null;
        log.info("触发自纠错重试（首次状态：{}）{}", first.status(),
                escalate ? "，并升级到 " + model : "");
        AgentResponse second = (apiKey != null && !apiKey.isBlank())
                ? askWithCorrection(question, first.sql(), feedback, model, apiKey)
                : askWithCorrection(question, first.sql(), feedback, model);
        EvaluationTrace.attempt("CORRECTION_SQL", second);
        if (second.success()) {
            // 择优而非覆盖：首次是「成功但可疑」时，第二次也必须通过同一套校验才配替换。
            // 否则会出现「首次正确、被规则误判 → 重试 → 第二次也能跑但答错 → 采用第二次」，
            // 准确率不升反降（这个坑在 ResultChecker 的比率规则上真实发生过）。
            if (firstSuspicion != null) {
                RequestBudget.stage("RESULT_CHECK");
                QueryResult qr2 = new QueryResult(second.columns(), second.rows(), second.truncated(), 0L);
                var secondCheck = resultChecker.check(question, second.sql(), qr2);
                if (secondCheck.suspicious()) {
                    log.info("重试结果仍被判定可疑（本次规则：{}，首次规则：{}），保留首次结果",
                            secondCheck.rule(), firstSuspicion);
                    return AgentResponse.combineAttempts(first, second, false);
                }
            }
            log.info("重试成功，采用第二次结果");
            EvaluationTrace.select(2);
            return AgentResponse.combineAttempts(first, second);
        }
        log.warn("重试仍未成功（{}），保留首次结果", second.status());
        return AgentResponse.combineAttempts(first, second, false);
    }

    /**
     * 把启发式校验的判定结果整理成「可执行的修改指令」。
     *
     * <p>和 {@link #retryFeedback} 的分工：那个对应「执行/校验失败」，模型本来就知道错在哪；
     * 这个对应「执行成功但结果可疑」，模型自己看不到问题，所以必须把命中的规则、
     * 判定依据、问题原文、实际返回的行数与列名都摆出来。否则模型只能盲改，
     * 很容易把本来正确的部分一起改坏——这也是「重试反而降准确率」的另一半原因。
     */
    private static String correctionFeedback(String question, AgentResponse first, CheckResult check) {
        StringBuilder sb = new StringBuilder();
        sb.append("上一条 SQL 已成功执行，但触发了结果合理性校验，判定结果可能不对。\n");
        sb.append("命中规则：").append(check.rule()).append('\n');
        sb.append("判定依据：").append(check.reason()).append('\n');
        sb.append("用户问题：").append(question).append('\n');
        sb.append("上一条 SQL：\n").append(first.sql()).append('\n');
        int rows = first.rows() == null ? 0 : first.rows().size();
        sb.append("实际返回：").append(rows).append(" 行");
        if (first.columns() != null && !first.columns().isEmpty()) {
            sb.append("，输出列：").append(String.join(", ", first.columns()));
        }
        sb.append("\n请只针对上述可疑点做最小修改，重新给出完整 SQL，已经正确的部分不要改动：\n");
        sb.append("- 问题要求的每个维度（时间/地区/类目）和指标都必须出现在 SELECT 或 GROUP BY 中，输出列不能少\n");
        sb.append("- 聚合口径要与问题一致：问「平均」用 AVG，问「多少笔/多少个」用 COUNT，需要去重时用 COUNT(DISTINCT ...)\n");
        sb.append("- WHERE 里的枚举、状态、地区取值必须与 schema 中给出的实际值一致，注意大小写与拼写\n");
        sb.append("- 只使用 schema 中真实存在的表和列，数值 ROUND 到两位小数，并保留 LIMIT\n");
        return sb.toString();
    }

    /** 把首次失败的真实原因整理成反馈。**只包含模型自己能观察到的信息，不含标准答案。** */
    private static String retryFeedback(AgentResponse first) {
        StringBuilder sb = new StringBuilder();
        sb.append("上一条 SQL 执行结果是：").append(first.status()).append('\n');
        if (first.sql() != null && !first.sql().isBlank()) {
            sb.append("上一条 SQL：\n").append(first.sql()).append('\n');
        }
        if (first.message() != null && !first.message().isBlank()) {
            sb.append("具体错误：").append(first.message()).append('\n');
        }
        sb.append("请修正后重新给出 SQL：只使用上面 schema 里真实存在的表和列，"
                + "只保留问题要求的输出列，数值统一 ROUND 到两位小数，"
                + "按时间分组用 DATE_TRUNC，并保留 LIMIT。\n");
        return sb.toString();
    }

    /**
     * 跳过生成，直接跑「校验 → 执行」。
     *
     * <p>存在的唯一目的是评估器自检（dry-run）：拿评估集里的 gold_sql 当输入，
     * 跑一遍下游链路。如果连标准 SQL 都跑不到 100% 一致，说明问题出在
     * 规范化规则或比对逻辑上，此时任何准确率数字都不可信。
     *
     * <p>这是「把评估器自身的 bug 和模型不准分开」的具体手段。没有这一步，
     * 第一次跑出 60% 的时候你无法判断这个 60% 是不是假的。
     *
     * @param llmCall 自检时传 null；正常链路传入真实调用记录
     */
    public AgentResponse askWithFixedSql(String question, String sql, LlmCallRecord llmCall) {
        long totalStarted = System.nanoTime();
        long retrievalStarted = System.nanoTime();
        SchemaContext retrieved = schemaProvider.provide(question);
        long retrievalMs = elapsedMs(retrievalStarted);
        // dry-run 的输入是 trusted gold SQL：校验用全量 schema，避免把
        // gold 里「不产出列、只起过滤作用」的 join 误判成检索漏表。
        // 检索指标仍按 retrieved 记录，召回率不会因此虚高。
        SchemaContext validationSchema = properties.getEval().isDryRun()
                ? schemaProvider.fullSchema() : retrieved;
        return validateAndExecute(question, sql, llmCall, validationSchema,
                retrieved.tables().size(), retrieved.tableNames(),
                retrieved.ddlText() == null ? 0 : retrieved.ddlText().length(),
                retrievalMs, 0, totalStarted);
    }

    /**
     * 阶段 5 自纠错入口：保留第一次 SQL，由评估器或上层调用方提供反馈，
     * 再走一次「生成 → 校验 → 执行」完整链路。
     */
    public AgentResponse askWithCorrection(String question, String previousSql, String feedback) {
        return askWithCorrection(question, previousSql, feedback, null, null);
    }

    /**
     * @param modelOverride 非空时换用这个模型重试（阶段 6 的升级路由）
     */
    public AgentResponse askWithCorrection(String question, String previousSql, String feedback,
                                           String modelOverride) {
        return askWithCorrection(question, previousSql, feedback, modelOverride, null);
    }

    /**
     * 支持动态 API Key 覆盖的自纠错入口。
     */
    public AgentResponse askWithCorrection(String question, String previousSql, String feedback,
                                           String modelOverride, String apiKey) {
        return RequestBudgetRunner.run(question, null, properties.getRequestBudget(),
                () -> correctionPipeline(question, previousSql, feedback, modelOverride, apiKey));
    }

    private AgentResponse correctionPipeline(String question, String previousSql, String feedback,
                                              String modelOverride, String apiKey) {
        long totalStarted = System.nanoTime();
        RequestBudget.stage("RETRIEVAL");
        long retrievalStarted = System.nanoTime();
        SchemaContext schema = schemaProvider.provide(question);
        RequestBudget.schema(schema);
        long retrievalMs = elapsedMs(retrievalStarted);
        int tableCount = schema.tables().size();
        List<String> retrievedTables = schema.tableNames();
        int ddlChars = schema.ddlText() == null ? 0 : schema.ddlText().length();

        RequestBudget.stage("GENERATION");
        long generationStarted = System.nanoTime();
        GeneratedSql generated;
        try {
            generated = (apiKey != null && !apiKey.isBlank())
                    ? generator.generateCorrection(question, schema, previousSql, feedback, modelOverride, apiKey)
                    : generator.generateCorrection(question, schema, previousSql, feedback, modelOverride);
        } catch (GenerationException e) {
            long generationMs = elapsedMs(generationStarted);
            AgentResponse.Status status = e.getReason() == GenerationException.Reason.NOT_CONFIGURED
                    ? AgentResponse.Status.NOT_CONFIGURED
                    : AgentResponse.Status.GENERATION_FAILED;
            return AgentResponse.failed(question, status, null, e.getMessage(), e.getCallRecord(), tableCount,
                    retrievedTables, ddlChars,
                    timings(retrievalMs, generationMs, 0, 0, elapsedMs(totalStarted)));
        }
        long generationMs = elapsedMs(generationStarted);
        return validateAndExecute(question, generated.sql(), generated.call(), schema, tableCount,
                retrievedTables, ddlChars, retrievalMs, generationMs, totalStarted);
    }

    private AgentResponse validateAndExecute(String question, String sql, LlmCallRecord llmCall,
                                             SchemaContext schema, int tableCount,
                                             List<String> retrievedTables,
                                             int ddlChars,
                                             long retrievalMs, long generationMs, long totalStarted) {
        RequestBudget.stage("VALIDATION");
        long validationStarted = System.nanoTime();
        ValidationResult validation = validator.validate(sql, schema);
        long validationMs = elapsedMs(validationStarted);

        if (!validation.valid()) {
            List<String> violations = validation.violations().stream()
                    .map(v -> "[" + v.code() + "] " + v.message())
                    .toList();
            log.info("SQL 被校验层拦下：{}", validation.describe());
            return AgentResponse.rejected(question, validation.sql(), violations, llmCall, tableCount,
                    retrievedTables, ddlChars,
                    timings(retrievalMs, generationMs, validationMs, 0, elapsedMs(totalStarted)));
        }

        // 阶段 5 闭环防御：EXPLAIN 执行代价与全表笛卡尔积预执行护栏
        // dry-run 用 trusted gold SQL 自检，不应用运行时代价护栏去卡它；
        // 代价护栏的职责是拦截模型生成的慢查询/笛卡尔积。
        if (!properties.getEval().isDryRun()
                && properties.getGuard().isExplainCostGuardEnabled()
                && queryPlanAnalyzer != null) {
            RequestBudget.stage("EXPLAIN");
            var analysis = queryPlanAnalyzer.analyze(validation.sql());
            if (!analysis.safe()) {
                log.warn("SQL 触发高危执行计划护栏拦截：{}", analysis.riskDescription());
                List<String> violations = List.of("[HIGH_RISK_COST] " + analysis.riskDescription());
                return AgentResponse.rejected(question, validation.sql(), violations, llmCall, tableCount,
                        retrievedTables, ddlChars,
                        timings(retrievalMs, generationMs, validationMs, 0, elapsedMs(totalStarted)));
            }
        }

        RequestBudget.stage("EXECUTION");
        long executionStarted = System.nanoTime();
        QueryResult result;
        try {
            // 用 validation.sql() 而不是原始 sql：校验层可能补了 LIMIT，
            // 执行的和记录的必须是同一条语句。
            result = executor.execute(validation.sql());
        } catch (SqlExecutionException e) {
            long executionMs = elapsedMs(executionStarted);
            log.warn("SQL 执行失败：{}", e.getMessage());
            // 必须带上 validation.sql()：执行失败的 SQL 正是排查失败原因的唯一线索，
            // 早先这里传 null，导致报告里 19 条执行失败看不到 SQL。
            return AgentResponse.failed(question, AgentResponse.Status.EXECUTION_FAILED, validation.sql(),
                    e.getMessage(), llmCall, tableCount,
                    retrievedTables, ddlChars,
                    timings(retrievalMs, generationMs, validationMs, executionMs, elapsedMs(totalStarted)));
        }
        long executionMs = elapsedMs(executionStarted);

        AgentResponse.Timings timings = timings(retrievalMs, generationMs, validationMs, executionMs,
                elapsedMs(totalStarted));

        return AgentResponse.success(question, validation.sql(), validation.rewritten(),
                new AgentResponse.QueryOutcome(result.columns(), result.rows(), result.truncated()),
                llmCall, tableCount, retrievedTables, ddlChars, timings);
    }

    private static AgentResponse.Timings timings(long retrieval, long generation, long validation,
                                                 long execution, long total) {
        return new AgentResponse.Timings(retrieval, generation, validation, execution, total);
    }

    private static long elapsedMs(long startedNanos) {
        return (System.nanoTime() - startedNanos) / 1_000_000;
    }
}
